# @babel/helper-optimise-call-expression

> Helper function to optimise call expression

See our website [@babel/helper-optimise-call-expression](https://babeljs.io/docs/en/babel-helper-optimise-call-expression) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-optimise-call-expression
```

or using yarn:

```sh
yarn add @babel/helper-optimise-call-expression --dev
```
